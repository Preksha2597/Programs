package com.cg.bank.service;

import java.util.List;
import java.util.Random;

import com.cg.bank.bean.AccountDetails;
import com.cg.bank.bean.Transaction;
import com.cg.bank.exception.BankException;
import com.cg.bank.persistence.BankRepoImpl;

public class BankServiceImpl implements IBankService
{
private static final String mobile = null;
BankRepoImpl repo = new BankRepoImpl();

@Override
public long addAccount(AccountDetails a) throws BankException {
	// TODO Auto-generated method stub
	return repo.addAccount(a);
}

@Override
public double showBalance(long accNum) throws BankException {
	// TODO Auto-generated method stub
	return repo.showBalance(accNum);
}

@Override
public String deposit(long accNum, double deposit) throws BankException {
	// TODO Auto-generated method stub
	return repo.deposit(accNum, deposit);
}

@Override
public String withdraw(long accNum, double withdraw) throws BankException {
	// TODO Auto-generated method stub
	return repo.withdraw(accNum, withdraw);
}

@Override
public boolean fundTransfer(long accNum1, long accNum2, double amount) throws BankException {
	// TODO Auto-generated method stub
	return repo.fundTransfer(accNum1, accNum2, amount);
}

@Override
public Transaction printTransactions(long accNum) throws BankException {
	// TODO Auto-generated method stub
	return repo.printTransactions(accNum);
}

@Override
public List<AccountDetails> printAll() throws BankException {
	// TODO Auto-generated method stub
	return repo.printAll();
}

@Override
public boolean accountNumberValidation(long accNum) {
	// TODO Auto-generated method stub
    String stringAccNum =accNum+""; 
	String regEx="[0-9]{3}";
	if(stringAccNum.matches(regEx))
	return true;
	else
    return false;
}

@Override
public boolean phoneNumberValidation(long mobile) {
	// TODO Auto-generated method stub
	String stringMobile=mobile+"";
	String regEx1 ="(91|0)?[6-9][0-9]{9}";
	if(stringMobile.matches(regEx1))
	return true;
	else
		return false;
}

@Override
public boolean emailvalidation(String mailId) {
	// TODO Auto-generated method stub
	String regEx2 = "[a-zA-Z0-9]+[@][a-zA-Z0-9]+([.][a-zA-Z]{2,})+";
if(mailId.matches(regEx2))
	return true;
else
return false;
}

}

