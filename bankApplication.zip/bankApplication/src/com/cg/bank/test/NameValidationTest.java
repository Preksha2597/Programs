package com.cg.bank.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class NameValidationTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
