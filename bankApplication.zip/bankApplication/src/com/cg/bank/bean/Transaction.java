package com.cg.bank.bean;


import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Iterator;

public class Transaction {
String msg;
LocalDate d;
LocalTime t;
double amount;
public String getMsg() {
	return msg;
}
public void setMsg(String msg) {
	this.msg = msg;
}
public LocalDate getD() {
	return d;
}
public void setD(LocalDate d) {
	this.d = d;
}
public LocalTime getT() {
	return t;
}
public void setT(LocalTime t) {
	this.t = t;
}
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}
@Override
public String toString() {
	return "Transaction [msg=" + msg + ", d=" + d + ", t=" + t + ", amount=" + amount + "]";
}
public Iterator<Transaction> iterator() {
	// TODO Auto-generated method stub
	return null;
}

}
