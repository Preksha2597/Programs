package com.cg.bank.bean;

import java.util.ArrayList;
import java.util.List;

public class AccountDetails {
		private long accNum;
		private String name;
		private long mobile;
		private String address;
		private double balance;
		private String mailId;
		
 List<Transaction> t = new ArrayList<>();

public long getAccNum() {
	return accNum;
}

public void setAccNum(long accNum) {
	this.accNum = accNum;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public long getMobile() {
	return mobile;
}

public void setMobile(long mobile) {
	this.mobile = mobile;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public double getBalance() {
	return balance;
}

public void setBalance(double balance) {
	this.balance = balance;
}

public List<Transaction> getT() {
	return t;
}

public void setT(Transaction t) {
	this.t.add((Transaction) t) ;
}


public String getMailId() {
	return mailId;
}

public void setMailId(String mailId) {
	this.mailId = mailId;
}

@Override
public String toString() {
	return "AccountDetails [accNum=" + accNum + ", name=" + name + ", mobile=" + mobile + ", address=" + address
			+ ", balance=" + balance + ", mailId=" + mailId + ", t=" + t + "]";
}

}

