package com.cg.bank.UI;
import java.util.Random;
import java.util.Scanner;

import com.cg.bank.bean.AccountDetails;
import com.cg.bank.exception.BankException;
import com.cg.bank.service.BankServiceImpl;

	public class BankAccInterface {
	
		public static void main(String[] args) throws BankException 
		{
			char cho = 'y';
			BankServiceImpl service = new BankServiceImpl ();
			Scanner sc = new Scanner(System.in);
			while (cho =='y')
			{
				AccountDetails a = new AccountDetails();
			System.out.println("1. createAccount");
			System.out.println("2. showBalance");		
		    System.out.println("3. depositAmount");
		    System.out.println("4. withdrawAmount");
		    System.out.println("5. fundTransfer");
			System.out.println("6. printTransaction");
			System.out.println("7. printAll");
			System.out.println("8. Exit");
			int ch = sc.nextInt();
			switch(ch) 
			{ 
			case 1:
	         System.out.println("enter account number ");
	         long accNum=sc.nextLong();
	         while(!(service.accountNumberValidation(accNum)))
	         {
	        	 System.out.println("Invalid account number!enter again");
	        	 accNum=sc.nextLong();
	         }
	         a.setAccNum(accNum);
				System.out.println("enter name");
					a.setName(sc.next());
				System.out.println("enter address");
					a.setAddress(sc.next());
				System.out.println("enter phone");
				long mobile=sc.nextLong();
				while(!(service.phoneNumberValidation(mobile)))
						{
							System.out.println("Invalid phone number! enter again");
							mobile=sc.nextLong();
						}
				  a.setMobile(mobile);
				System.out.println("enter email id ");
				String mailId=sc.next();
				while(!(service.emailvalidation(mailId)))
						{
							System.out.println("Invalid email Id! enter again");
							mailId=sc.next();
						}
				  
				service.addAccount(a);
				System.out.println("Account created" );
				//System.out.println("do you want to continue ? (y/n)");
				break;
				
			case 2:
				System.out.println("Enter account number");
				System.out.println(service.showBalance(sc.nextLong()));
				break;
			case 3:
				System.out.println("Enter account number");
				 accNum = sc.nextLong();
				System.out.println("enter deposited amount");
				double deposit = sc.nextDouble();
				System.out.println(service.deposit(accNum, deposit));
				break;
			
			case 4:
				System.out.println("Enter account number");
				accNum = sc.nextLong();
				System.out.println("enter withdraw amount");
				double withdraw = sc.nextDouble();
				System.out.println(service.withdraw(accNum, withdraw));
				break;
			case 5:
				System.out.println("Enter your account number");
				 long accNum1 = sc.nextLong();
				System.out.println("Enter your friend's account number");
				 long accNum2 = sc.nextLong();
				 System.out.println("Enter amount transfered ");
				  double fund  = sc.nextDouble();
				 System.out.println(service.fundTransfer(accNum1, accNum2, fund));
				 break;
				
			case 6: 
				System.out.println("Enter account number");
				accNum = sc.nextLong();
				System.out.println(service.printTransactions(accNum));
				break;
			case 7:
			      System.out.println(service.printAll());
				break;
			case 8:
				System.exit(0);
						}
			System.out.println("do you want to continue with bank details? (y/n)");
			cho=sc.next().charAt(0);
					}
		}
	}
			
		
