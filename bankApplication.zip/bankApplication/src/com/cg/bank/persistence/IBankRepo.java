package com.cg.bank.persistence;

import java.util.List;

import com.cg.bank.bean.AccountDetails;
import com.cg.bank.bean.Transaction;
import com.cg.bank.exception.BankException;

public interface IBankRepo {



		long  addAccount(AccountDetails a)throws BankException;
		double showBalance(long accNum)throws BankException;
		String deposit(long accNum, double deposit)throws BankException;
		String withdraw(long accNum, double withdraw)throws BankException;
		boolean fundTransfer(long accNum1, long accNum2, double amount)throws BankException;
		Transaction printTransactions(long accNum)throws BankException;
		List<AccountDetails> printAll() throws BankException;

	}
