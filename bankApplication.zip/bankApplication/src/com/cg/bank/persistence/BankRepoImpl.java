package com.cg.bank.persistence;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.cg.bank.bean.AccountDetails;
import com.cg.bank.bean.Transaction;
import com.cg.bank.exception.BankException;

public class BankRepoImpl implements IBankRepo {
List<AccountDetails> list = new ArrayList<>();
AccountDetails acd=new AccountDetails();
	@Override
	public long addAccount(AccountDetails a) throws BankException {
		// TODO Auto-generated method stub
		try {
			list.add(a);
		}
		catch(Exception e )
		{
			System.err.println("Error in DAO (Creation of new Account):"+e);
		}
		return a.getAccNum();
	}

	@Override
	public double showBalance(long accNum) throws BankException {
		double balance=0;
		try {
			for(AccountDetails i:list)
			{
				if(i.getAccNum()==accNum)
					balance=i.getBalance();
			}
			}
		catch(Exception e)
		{
			System.err.println("Error in DAO(Show Balance):"+e);
		}
		// TODO Auto-generated method stub
		return balance;
	}

	@Override
	public String deposit(long accNum, double deposit) throws BankException {
		// TODO Auto-generated method stub
		String msg="";
		try
		{
            for(AccountDetails i:list)
            {
            	if(i.getAccNum()==accNum)
            	{
            		double bal=i.getBalance();
            		bal = bal +deposit;
        			i.setBalance(bal);
        			Transaction t = new Transaction();
                    t.setAmount(deposit);
                    t.setMsg("credit");
                    t.setD(LocalDate.now());
                    t.setT(LocalTime.now());
                    i.setT(t);
                    msg=t.getMsg();
                    break;
            	}
            }
		}
		catch(Exception e)
		{
		System.err.println("Error in DAO:"+e);
		}
		
		return msg;
	}

	@Override
	public String withdraw(long accNum, double withdraw) throws BankException {
		// TODO Auto-generated method stub
		double minBal=0;
		String msg="";
		try
		{
			for(AccountDetails i:list)
			{
				if(i.getAccNum()==accNum)
				{
					double bal = i.getBalance();
					if(bal<=minBal)
						System.err.println("Sorry your balance is low");
					else
					{
						bal-=withdraw;
						i.setBalance(bal);
                        Transaction t = new Transaction();
                        t.setAmount(withdraw);
                        t.setMsg("debit");
                        t.setD(LocalDate.now());
                        t.setT(LocalTime.now());
                        i.setT(t);
                        msg=t.getMsg();
                        break;
                        }
				}
			}
		}
		catch(Exception e)
		{
			System.err.println("Error in DAO in withdrawing amount:"+e);
		}
		return null;
	}

	@Override
	public boolean fundTransfer(long accNum1, long accNum2, double amount) throws BankException {
		// TODO Auto-generated method stub
		try
		{
			for(AccountDetails i:list)
			{
				if(i.getAccNum()==accNum1)
				{
					for(AccountDetails j:list)
					{
						if(i.getAccNum()==accNum2)
						{
							double bal1 =i.getBalance();
							bal1-= amount;
							double bal2=i.getBalance();
							bal2+= amount;
							i.setBalance(bal1);
							i.setBalance(bal2);
							return true;
						}
					}
				}
			}
		}
		catch(Exception e)
		{
			System.err.println("Error in DAO in fund transfer:"+e);
		}
		return false;
	}

	@Override
	public Transaction printTransactions(long accNum) throws BankException {
		// TODO Auto-generated method stub
		Transaction tran = new Transaction();
		try
		{
			for(AccountDetails i:list)
			{
				if(i.getAccNum()==accNum)
				{
					tran=(Transaction) i.getT();
					Iterator<Transaction> it = tran.iterator();
					while(it.hasNext()){
						System.out.println(it.next());
				}
			}
		}
		}
		catch(Exception e)
		{
		System.err.println("Error in DAo in printing transaction:"+e);	
		}
		
		return null;
	}

	@Override
	public List<AccountDetails> printAll() throws BankException {
		// TODO Auto-generated method stub
		List<AccountDetails> print=null;
		try
		{
			print=list;
		}
		catch(Exception e)
		{
			System.err.println("Error in DAO in printing details of all customers:"+e);
		}
		
		return print;
	}

}
