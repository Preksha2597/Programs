package stepDefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Test_manuallyUpdateEquipment {
	@Given("^Authorised user is logged in$")
	public void authorised_user_is_logged_in() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		System.out.println("Authorised user is logged in");
	}

	@When("^User clicks on Update multiple equipments$")
	public void user_clicks_on_Update_multiple_equipments() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("User clicks on Update multiple equipments");
}

	@Then("^system displays equipment list with records which are editable$")
	public void system_displays_equipment_list_with_records_which_are_editable() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		System.out.println("system displays equipment list with records which are editable");
}

	@Then("^user can make changes to any equipment details simultaneously$")
	public void user_can_make_changes_to_any_equipment_details_simultaneously() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("user can make changes to any equipment details simultaneously");
}


}
