package stepDefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Test_authorisedUsers {
	@Given("^on home page$")
	public void on_home_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("On home page");
	}

	@Given("^User wants to update equipment$")
	public void user_wants_to_update_equipment() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("user wants to update equipment");
}

	@When("^User clicks on update button$")
	public void user_clicks_on_update_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("User clicks on update button");
}

	@Then("^check whether the user is Inventory personnel$")
	public void check_whether_the_user_is_Inventory_personnel() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("check whether the user is Inventory personnel");
}

	@Then("^check whether the user is Equipment auditors$")
	public void check_whether_the_user_is_Equipment_auditors() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("check whether the user is Equipment auditors");
}

	@Then("^check whether the user is Service personnel$")
	public void check_whether_the_user_is_Service_personnel() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("check whether the user is Service personnel");
}

	@Then("^check whether the user is Maintanence personnel$")
	public void check_whether_the_user_is_Maintanence_personnel() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("check whether the user is Maintanence personnel");
}

	@Then("^check whether the user is Equipment tracking personnel$")
	public void check_whether_the_user_is_Equipment_tracking_personnel() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		System.out.println("check whether the user is Equipment tracking personnel");
}


}
