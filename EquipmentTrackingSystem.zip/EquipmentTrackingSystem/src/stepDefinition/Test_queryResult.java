package stepDefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Test_queryResult {
	@Given("^User is on searche page$")
	public void user_is_on_searche_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	System.out.println("user is on search page");
	}

	@When("^user search for equipment$")
	public void user_search_for_equipment() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		System.out.println("user search for equipment");
}

	@Then("^user see a \"([^\"]*)\"$")
	public void user_see_a(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 //   throw new PendingException();
		System.out.println("user see");
}

	@Then("^see Equipment Tag, Quantity,  Seq\\. Number, User Id, Location, Equipment type for each equipment$")
	public void see_Equipment_Tag_Quantity_Seq_Number_User_Id_Location_Equipment_type_for_each_equipment() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 //   throw new PendingException();
		System.out.println("user see equipment details");
}


}
