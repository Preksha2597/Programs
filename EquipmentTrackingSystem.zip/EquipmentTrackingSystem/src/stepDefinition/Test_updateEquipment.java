package stepDefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Test_updateEquipment {
	@Given("^User is on desired update page$")
	public void user_is_on_desired_update_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("User is on desired update page");
	}

	@When("^User wants to update equipment record$")
	public void user_wants_to_update_equipment_record() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("User wants to update equipment record");
		}

	@Then("^He must enter type properties of the equipment he wants to update$")
	public void he_must_enter_type_properties_of_the_equipment_he_wants_to_update() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 //   throw new PendingException();
		System.out.println("enter type properties of the equipment he wants to update");
}

	@Then("^He must enter valid location$")
	public void he_must_enter_valid_location() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("He must enter valid location");
}

	@Then("^He must assign valid user$")
	public void he_must_assign_valid_user() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("He must assign valid user");
}


}
