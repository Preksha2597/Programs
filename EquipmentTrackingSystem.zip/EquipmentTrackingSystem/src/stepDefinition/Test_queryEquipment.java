package stepDefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Test_queryEquipment {
	@Given("^User clicks on query button$")
	public void user_clicks_on_query_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("User clicks on query button");
	}

	@When("^User enters equipment tag value to search$")
	public void user_enters_equipment_tag_value_to_search() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("User enters equipment tag value to search");
}

	@Then("^must be displayed equipments related to the entered equipment tag$")
	public void must_be_displayed_equipments_related_to_the_entered_equipment_tag() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("must be displayed equipments related to the entered equipment tag");
}

	@Then("^validate the \"([^\"]*)\" must have (\\d+) charecters$")
	public void validate_the_must_have_charecters(String arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("validate");
}

	@When("^User enters seq number value to search$")
	public void user_enters_seq_number_value_to_search() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("User enters seq number value to search");
}

	@Then("^must be displayed equipments related to the entered \"([^\"]*)\"$")
	public void must_be_displayed_equipments_related_to_the_entered(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("must be displayed equipments related to the entered");
}

	@When("^User enters machine id value to search$")
	public void user_enters_machine_id_value_to_search() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("User enters machine id value to search");
}

	@When("^User enters user id value to search$")
	public void user_enters_user_id_value_to_search() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("User enters user id value to search");
}

	@When("^User enters location value to search$")
	public void user_enters_location_value_to_search() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("User enters location value to search");
}

	@Then("^must be displayed equipments related to the entered mumbai$")
	public void must_be_displayed_equipments_related_to_the_entered_mumbai() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("must be displayed equipments related to the entered mumbai");
}

	@Then("^must be displayed equipments related to the entered hyderabad$")
	public void must_be_displayed_equipments_related_to_the_entered_hyderabad() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("must be displayed equipments related to the entered hyderabad");
}

	@Then("^must be displayed equipments related to the entered kolkata$")
	public void must_be_displayed_equipments_related_to_the_entered_kolkata() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("must be displayed equipments related to the entered kolkata");
}

	@Then("^must be displayed equipments related to the entered chandigarh$")
	public void must_be_displayed_equipments_related_to_the_entered_chandigarh() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("must be displayed equipments related to the entered chandigarh");
}


}
