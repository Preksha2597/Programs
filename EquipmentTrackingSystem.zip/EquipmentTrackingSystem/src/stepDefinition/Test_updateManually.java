package stepDefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Test_updateManually {
	@Given("^User is on home page$")
	public void user_is_on_home_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	 //   throw new PendingException();
		System.out.println("^User is on home page");
	}

	@When("^User clicks on any equipment update button$")
	public void user_clicks_on_any_equipment_update_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		System.out.println("User clicks on any equipment update button");
}

	@Then("^check \"([^\"]*)\" and \"([^\"]*)\" is same$")
	public void check_and_is_same(String arg1, String arg2) throws Throwable {
	   // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("check");
}

	@Then("^show user the update page$")
	public void show_user_the_update_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("^show user the update page");
}

	@When("^User clicks on a retired equipment update button$")
	public void user_clicks_on_a_retired_equipment_update_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.out.println("User clicks on a retired equipment update button");
}

	@Then("^let only update the comments$")
	public void let_only_update_the_comments() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  // throw new PendingException();
		System.out.println("let only update the comments");
}

	@Given("^Found equipment that is marked Spare Part$")
	public void found_equipment_that_is_marked_Spare_Part() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		System.out.println("Found equipment that is marked Spare Part");
	}

	@Then("^move that equipment to In Stock$")
	public void move_that_equipment_to_In_Stock() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		System.out.println("move that equipment to In Stock");
}


}
