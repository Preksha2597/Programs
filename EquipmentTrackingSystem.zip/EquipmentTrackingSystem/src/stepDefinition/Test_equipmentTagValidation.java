package stepDefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Test_equipmentTagValidation {
	@Given("^User is on update tag page$")
	public void user_is_on_update_tag_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  //  throw new PendingException();
		System.out.println("User is on update tag page");
	}

	@When("^User entered a tag$")
	public void user_entered_a_tag() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("User entered a tag");
}

	@When("^clicks on update$")
	public void clicks_on_update() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("clicks on update");
}

	@Then("^validate the tag must have (\\d+) charecters$")
	public void validate_the_tag_must_have_charecters(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("validate the tag");
}

	@Then("^Equipment Tag must be all numeric$")
	public void equipment_Tag_must_be_all_numeric() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("Equipment Tag must be all numeric");
}

	@Then("^Equipment Tag will remove any blanks or dashes$")
	public void equipment_Tag_will_remove_any_blanks_or_dashes() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("Equipment Tag will remove any blanks or dashes");
}

	@Then("^The text 'AD' will be removed from Equipment Tag if found in position (\\d+) and (\\d+) of the character string$")
	public void the_text_AD_will_be_removed_from_Equipment_Tag_if_found_in_position_and_of_the_character_string(int arg1, int arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("The text 'AD' will be removed from Equipment Tag if found in position");
	}

	@Then("^Equipment Tag will be padded with leading zeros if length is less than (\\d+) characters$")
	public void equipment_Tag_will_be_padded_with_leading_zeros_if_length_is_less_than_characters(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("Equipment Tag will be padded with leading zeros");
}

	@Then("^display the success message$")
	public void display_the_success_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		System.out.println("display the success message");
}


}
