package com.capgemini.takehome.bean;

import  java.util.HashMap;
import java.util.Map;

public class BillDetails {

private int Product_code;
private int Quantity;
private double line_total;

Map<Integer, Product> t = new HashMap<Integer, Product>();

public int getProduct_code() {
	return Product_code;
}

public void setProduct_code(int product_code) {
	Product_code = product_code;
}

public int getQuantity() {
	return Quantity;
}

public void setQuantity(int quantity) {
	Quantity = quantity;
}

public double getLine_total() {
	return line_total;
}

public void setLine_total(double line_total) {
	this.line_total = line_total;
}

public HashMap<Integer, Product> getT() {
	return (HashMap<Integer, Product>) t;
}

public void setT(HashMap<Integer, Product> t) {
	this.t = t;
}

@Override
public String toString() {
	return "BillDetails [Product_code=" + Product_code + ", Quantity=" + Quantity + ", line_total=" + line_total
			+ ", t=" + t + "]";
}

}
