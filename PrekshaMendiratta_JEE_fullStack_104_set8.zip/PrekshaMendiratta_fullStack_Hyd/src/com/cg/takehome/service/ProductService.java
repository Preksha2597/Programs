package com.cg.takehome.service;

import com.capgemini.takehome.bean.Product;
import com.cg.takehome.dao.ProductDAO;
import com.cg.takehome.service.IProductservice;
public class ProductService  implements IProductservice {
ProductDAO pdao = new ProductDAO();
	
	@Override
	public void getProductDetails(Product p) {
		// TODO Auto-generated method stub
		pdao.getProductDetails(p);
	}

	@Override
	public void calculateTotalCost(double product_price, int Quantity) {
		// TODO Auto-generated method stub
		pdao.calculateTotalCost(product_price, Quantity);
	}

	@Override
	public void generateBill(int product_code, int Quantity) {
		// TODO Auto-generated method stub
		pdao.generateBill(product_code, Quantity);
	}

	
		
	}

	


