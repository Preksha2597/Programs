package com.cg.takehome.service;

import com.capgemini.takehome.bean.Product;

public interface IProductservice {
	public void getProductDetails(Product p);
	public void calculateTotalCost(double product_price, int Quantity);
	public void generateBill(int product_code, int Quantity);	void getProductDetails();

}
