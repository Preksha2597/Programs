package com.cg.takehome.dao;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.capgemini.takehome.bean.BillDetails;
import com.capgemini.takehome.bean.Product;
import com.cg.takehome.dao.ProductDAO;


public class junit_test {

	@Test
	public void getProductDetails()
	{
		Product p =new Product();
		BillDetails bd = new BillDetails();
		Map<Integer, Product> t = new HashMap<Integer, Product>();
		ProductDAO pdao = new ProductDAO();
		bd.setProduct_code(1001);
		bd.setQuantity(2);
		bd.setLine_total(70000);
		assertEquals(1001, pdao.getProductDetails(p);
	}
	@Test
	public void calculateTotalCost()
	{
		ProductDAO pdao = new ProductDAO();
		assertEquals(70000, pdao.calculateTotalCost(35000, 2);
	}
	}
