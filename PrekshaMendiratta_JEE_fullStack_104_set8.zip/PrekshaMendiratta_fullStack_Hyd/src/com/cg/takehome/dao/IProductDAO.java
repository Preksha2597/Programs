package com.cg.takehome.dao;

import com.capgemini.takehome.bean.BillDetails;
import com.capgemini.takehome.bean.Product;

public interface IProductDAO {
public void getProductDetails(Product p);
public void calculateTotalCost(double product_price, int Quantity);
public void generateBill(int product_code, int Quantity);

}
