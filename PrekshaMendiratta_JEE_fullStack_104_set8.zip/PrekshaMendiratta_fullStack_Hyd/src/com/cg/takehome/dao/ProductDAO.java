package com.cg.takehome.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.takehome.bean.BillDetails;
import com.capgemini.takehome.bean.Product;

public class ProductDAO implements IProductDAO {

	BillDetails bd = new BillDetails();
	Map<Integer, Product> t = new HashMap<Integer, Product>();
	private double line_total =0;
	private Connection con = null;
	private PreparedStatement ps = null;
	 public void getConnection() throws ClassNotFoundException, SQLException {
		 Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@localhost:1521:XE";
			String user = "system";
			String pass = "Capgemini123";
		     con =  DriverManager.getConnection(url, user, pass);
	 }
	@Override
	public void getProductDetails(Product p) {
		// TODO Auto-generated method stub
		try {
			getConnection();
			ps=con.prepareStatement("insert into BillDetails values(?,?,?)");
			ps.setInt(1, bd.getProduct_code());
			ps.setInt(2, bd.getQuantity());
			ps.executeUpdate();
			System.out.println(p);
			con.close();
		}
		catch
		(Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public void calculateTotalCost(double product_price, int Quantity) {
		// TODO Auto-generated method stub
		System.out.println("in comission");
		double total;
		total = product_price *Quantity;
		
			}

	@Override
	public void generateBill(int product_code, int Quantity) {
		// TODO Auto-generated method stub
		try {
			PreparedStatement ps =con.prepareStatement("select * from  BillDetails where product_code="+product_code + "and Quantity="+Quantity);
			Scanner sc = new Scanner(System.in);
			System.out.println("enter product_code");
			int Product_code = sc.nextInt();
			System.out.println("enter quantity you want to purchase");
			Quantity = sc.nextInt();
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				System.out.println(ps);
				System.out.println("Quantity :" +Quantity);
				System.out.println("line total(Rs.);" +line_total);
			}
			}
			catch(Exception e)
			{
				System.out.println("Sorry! the product code"+product_code +"is not available");
			}		
		}
	}
	



