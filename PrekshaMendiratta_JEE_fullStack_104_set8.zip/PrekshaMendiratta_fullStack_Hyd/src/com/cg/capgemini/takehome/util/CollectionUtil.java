package com.cg.capgemini.takehome.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.capgemini.takehome.bean.Product;

public class CollectionUtil {

	public static void main(String[] args) {
		
	}
	private static Map<Integer, Product> prodcuts = new HashMap<Integer,Product>();

	private Map<Integer, Product> products;
	
	products.put(1001, new Product(1001, "iphone", "electronics" ,35000));
	products.put(1002, new Product(1002, "ledtv", "electronics" ,45000));
	products.put(1003, new Product(1003, "Teddy", "toys" ,800));
	products.put(1004, new Product(1004, "Telescope", "toys" ,5000));
	System.out.println(products);
	
	Set<Integer> s = products.keySet();
	Iterator<Integer> it = s.iterator();
	while (it.hasNext()) {
		int i = it.next();
		System.out.println(i + " " + products.get(1));
		
}
}
}
