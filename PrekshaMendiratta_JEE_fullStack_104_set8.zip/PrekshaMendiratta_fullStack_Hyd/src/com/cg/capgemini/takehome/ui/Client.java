package com.cg.capgemini.takehome.ui;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.takehome.bean.BillDetails;
import com.capgemini.takehome.bean.Product;
import com.cg.takehome.service.ProductService;



public class Client {
	private static final Logger logger =Logger.getLogger(Client.class);
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		ProductService service=new ProductService();
		
			while(true) {
				logger.info("\nEnter Your Choice: ");
				logger.info("1. enter the product you want to buy");
				logger.info("2. display the bill");
				logger.info("7. Exit");
				int m=sc.nextInt();
				switch(m) {
				case 1:	
				BillDetails bd=new BillDetails();
				Product p = new Product();
					logger.info("Enter Product_code:");
							int code = sc.nextInt();
							String pc = code +"";
							String regEx ="[0-9]{4}";
							while (!(pc.matches(regEx)))	
							{
							logger.info("enter valid product code");
							code = sc.nextInt();
							pc = code +"";
							}
							bd.setProduct_code(code);
					logger.info("enter the quantity");
							int quan = sc.nextInt();
						    String q = code +"";
						    String regEx1 ="[1-9]{1,}";
							while (!(q.matches(regEx1)))	
							{
								logger.info("enter correct quantity");
								quan = sc.nextInt();
								q = quan +"";
							}
							bd.setQuantity(quan);
						    service.getProductDetails(p);
				case 2: logger.info("enter the product code");
						 int Product_code = sc.nextInt();
						 logger.info("enter the quantity");
						 int quantity = sc.nextInt();
						 
						 service.generateBill(Product_code, quantity);
				case 3:System.exit(0);
				break;
					default:
						logger.info("Invalid Input");
						break;
					}
			}
	}
}