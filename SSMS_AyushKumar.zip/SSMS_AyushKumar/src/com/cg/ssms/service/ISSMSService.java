package com.cg.ssms.service;

import java.util.List;

import com.cg.ssms.bean.ScheduledSessions;

public interface ISSMSService {
	List<ScheduledSessions> showScheduledSessions();
}
