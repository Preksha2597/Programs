package com.cg.ssms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.ssms.bean.ScheduledSessions;
import com.cg.ssms.dao.ISSMSDao;

@Service
@Transactional
public class SSMSServiceImpl implements ISSMSService {
	@Autowired
	private ISSMSDao dao;

	public ISSMSDao getDao() {
		return dao;
	}

	public void setDao(ISSMSDao dao) {
		this.dao = dao;
	}

	@Override
	public List<ScheduledSessions> showScheduledSessions() {
		return dao.showScheduledSessions();
	}
	
}
