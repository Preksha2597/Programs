package com.cg.ssms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.ssms.bean.ScheduledSessions;
import com.cg.ssms.exception.SSMSException;

@Repository
public class SSMSDaoImpl implements ISSMSDao {
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<ScheduledSessions> showScheduledSessions() {
		try {
			TypedQuery<ScheduledSessions> query = entityManager.createQuery("SELECT scheduledsessions FROM ScheduledSessions scheduledsessions", ScheduledSessions.class);
			return query.getResultList();
		}	
		catch(Exception e){
			throw new SSMSException("App Exception: In DAO: Cannot Show Scheduled Sessions: "+ e.getMessage());
		}
	}
}
