package com.cg.ssms.exception;

public class SSMSException extends RuntimeException{
	public SSMSException(String msg) {
		super(msg); 
	}
}
