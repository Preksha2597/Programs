package com.cg.ssms.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ssms.exception.SSMSException;

@ControllerAdvice
	public class GlobalExceptionHandler {	
		@ExceptionHandler(value = {SSMSException.class})
	    protected ModelAndView handleConflict(Exception ex) {
			ModelAndView model = new ModelAndView("Error");
			model.addObject("msg", ex.getMessage());
			return model;
	    }
	}