package com.cg.ssms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.ssms.bean.ScheduledSessions;
import com.cg.ssms.exception.SSMSException;
import com.cg.ssms.service.ISSMSService;

@Controller
public class SSMSController {
	@Autowired
	private ISSMSService service;

	public ISSMSService getService() {
		return service;
	}

	public void setService(ISSMSService service) {
		this.service = service;
	}
	
	@RequestMapping("/showScheduledSessions")
	public ModelAndView showScheduledSessions() {
		try {
			ModelAndView mv = null;
			List<ScheduledSessions> list = service.showScheduledSessions();
			mv=new ModelAndView("ShowSessions", "list", list);
			return mv;
		}
		catch(Exception e) {
			throw new SSMSException("SSMS Exception: Cannot Show Sessions");
		}
	}
	
	@RequestMapping("/success")
	public ModelAndView success(@RequestParam("name") String name) {
		if(name!=null) {
			String msg="You Are Enrolled To: "+name+" Session";
			return new ModelAndView("Success", "msg", msg);
		}
		else {
			throw new SSMSException("SSMS Exception: Cannot Enroll To Session");
		}
	}
}