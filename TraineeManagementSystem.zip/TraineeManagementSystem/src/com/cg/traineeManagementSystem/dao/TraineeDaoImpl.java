package com.cg.traineeManagementSystem.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.traineeManagementSystem.bean.Trainee;


@Repository

public class TraineeDaoImpl implements ITraineeDao {

	
	
	@PersistenceContext
	private EntityManager entityManager;

	


	@Override
	public Trainee addTrainee(Trainee trainee) {
		entityManager.persist(trainee);
		entityManager.flush();
		return trainee;
	}


	@Override
	public Trainee getTraineeDetails(int id) {
		return entityManager.find(Trainee.class, id);
	}


	@Override
	public List<Trainee> getAllTraineeDetails() {
		TypedQuery<Trainee> query = entityManager.createQuery("SELECT trainee FROM Trainee trainee ", Trainee.class);
		return query.getResultList();
	}


	@Override
	public Trainee deleteTrainee(int id) {
		// TODO Auto-generated method stub
		Trainee trainee = entityManager.find(Trainee.class, id);
		entityManager.remove(trainee);;
		return trainee;
	}

	@Override
	public Trainee searchTrainee(int id) {
	// TODO Auto-generated method stub
	Trainee trainee = entityManager.find(Trainee.class, id);
	        
	        //Call remove method to remove the entity
	        return trainee;
	}

	@Override
	public Trainee updateTrainee(Trainee trainee) {
	// TODO Auto-generated method stub
	Trainee temp = entityManager.find(Trainee.class, trainee.getId());
	temp.setDomain(trainee.getDomain());
	//temp.setTraineeId(trainee.getTraineeId());
	temp.setLocation(trainee.getLocation());
	temp.setName(trainee.getName());
	//entityManager.commit();
	//entityManager.getTransaction().commit();
	//entityManager.merge(trainee);
	//modify trainee if you wish.
	//entityManager.commit();
	return trainee;
	}

}
