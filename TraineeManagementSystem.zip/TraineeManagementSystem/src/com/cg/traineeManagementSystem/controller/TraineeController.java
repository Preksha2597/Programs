package com.cg.traineeManagementSystem.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.traineeManagementSystem.bean.Trainee;
import com.cg.traineeManagementSystem.service.ITraineeService;



@Controller
public class TraineeController {
	
	@Autowired
	private ITraineeService obService;

	public ITraineeService getObService() {
		return obService;
	}

	public void setObService(ITraineeService obService) {
		this.obService = obService;
	}
	@RequestMapping("/showLogin")
	public String showLogin() {
		// Create an attribute of type Question
		return "login";
	}
	@RequestMapping("/loginValidation")
	public String test(@RequestParam("name") String name,
		@RequestParam("pwd") String pass,Model m)
	{
		if(name.equals("admin") && pass.equals("password"))
			return "Home";
		else
			return "login";
	}
	@RequestMapping("/showAddTrainee")
	public ModelAndView showAddDonation() {
		// Create an attribute of type Question
		Trainee trainee=new Trainee();
		// Add the attribute to the model and set the viewname and return it
		return new ModelAndView("addTrainee", "trainee", trainee);
	}
	@RequestMapping("/showHome")
	public String showHome() {
		// Create an attribute of type Question
		return "Home";
	}
	@RequestMapping("/addTrainee")
	public ModelAndView addTrainee(
			@ModelAttribute("trainee") @Valid Trainee trainee,
			BindingResult result) {

		ModelAndView mv = null;

		if (!result.hasErrors()) {
			obService.addTrainee(trainee);
			mv = new ModelAndView("Success");
			
		} else {
			mv = new ModelAndView("addTrainee", "trainee", trainee);
		}

		return mv;
	}
	/*@RequestMapping("/viewTrainee")
	public ModelAndView viewTrainee() {

		ModelAndView mv = new ModelAndView();

		List<Trainee> list = obService.getAllTraineeDetails();

			mv.setViewName("viewTrainee");
			// Add the attribute to the model
			mv.addObject("list", list);
	
		return mv;
	}*/
	                      //work on progress
	
	@RequestMapping("/showViewTrainee")
	public ModelAndView showViewTraineeForm() {

		// Create an attribute of type Question
		Trainee trainee=new Trainee();
		// Add the attribute to the model and return along with
		// the view name
		ModelAndView mv = new ModelAndView("viewTrainee");
		mv.addObject("trainee", trainee);
		mv.addObject("isFirst", "true");

		return mv;
	}

	@RequestMapping("/viewTrainee")
	public ModelAndView viewTrainee(@ModelAttribute("trainee") Trainee trainee) {

		ModelAndView mv = new ModelAndView();

		Trainee list=new Trainee();
		list = obService.getTraineeDetails(trainee.getId());

		if (list != null) {
			mv.setViewName("viewTrainee");
			mv.addObject("list", list);
		} else {
			String msg = "Enter a Valid Id!!";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		}

		return mv;
	}

	@RequestMapping("/showViewAllTrainees")
	public ModelAndView showViewAllTrainees() {

		ModelAndView mv = new ModelAndView();

		List<Trainee> list = obService.getAllTraineeDetails();
		if (list.isEmpty()) {
			String msg = "There are no Trainees";
			mv.setViewName("myError");
			mv.addObject("msg", msg);
		} else {
			mv.setViewName("viewAllTraineesList");
			// Add the attribute to the model
			mv.addObject("list", list);
		}
		return mv;
	}
	
	@RequestMapping("/showDeleteTrainee")
	public String showDeleteTrainee() {
		return "DeleteTrainee";
	}
	@RequestMapping("/deleteTrainee")
	public ModelAndView deleteTrainee(@RequestParam("id") int id,
			Model m) {
		ModelAndView mv = new ModelAndView();
		obService.deleteTrainee(id);
		List<Trainee> list = obService.getAllTraineeDetails();
		mv.setViewName("viewAllTraineesList");
		mv.addObject("list",list);
		return mv;
	}
	                               //update
	@RequestMapping("/showSearchTraineeForm")
	public String searchTraineeForm() {
	return "searchTraineeForm";
	}

	@RequestMapping("/searchTrainee")
	public ModelAndView searchTrainee(@RequestParam("traineeId") int traineeId) {
	ModelAndView mv = null;
	Trainee trainee = obService.searchTrainee(traineeId);
	if (trainee != null) {
	mv = new ModelAndView("showTraineePage", "trainee", trainee);
	} else
	mv = new ModelAndView("searchTraineeForm", "message", "Please, Enter a valid Id or the id is not present");

	return mv;
	}

	@RequestMapping("/showUpdateTraineeForm")
	public ModelAndView updateTraineeForm() {
	Trainee trainee = null;
	// Add the attribute to the model and set the viewname and return it
	return new ModelAndView("updateTraineeForm", "trainee", trainee);
	}

	@RequestMapping("/updateTrainee")
	public ModelAndView updateTrainee(@RequestParam("id") int id) {
	ModelAndView mv = null;
	Trainee trainee = obService.searchTrainee(id);

	if (trainee != null) {
	trainee.setId(id);
	mv = new ModelAndView("updateTraineeForm", "trainee", trainee);
	} else
	mv = new ModelAndView("updateTraineeForm", "message", "Please, Enter a valid Id or the id is not present");

	return mv;
	}

	@RequestMapping("/updateTraineeInDB")
	public ModelAndView updateTraineeInDB(@ModelAttribute("trainee") @Valid Trainee trainee, BindingResult result) {
	ModelAndView mv = null;
	System.out.println(trainee.getId() + " ############################## " + trainee.getName());

	if (!result.hasErrors()) {
	//trainee.setTraineeId(traineeId);
	Trainee status = obService.updateTrainee(trainee);
	mv = new ModelAndView("Success");
	mv.addObject("traineeId", trainee.getId());
	mv.addObject("traineeName", trainee.getName());
	} else {
	mv = new ModelAndView("updateTraineeForm", "trainee", trainee);
	}

	return mv;
	}
}
