package com.cg.traineeManagementSystem.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.traineeManagementSystem.bean.Trainee;
import com.cg.traineeManagementSystem.dao.ITraineeDao;

@Service
@Transactional
public class TraineeServiceImpl implements ITraineeService {
	
	@Autowired
	ITraineeDao obDao;
	
	
	
	public ITraineeDao getObDao() {
		return obDao;
	}



	public void setObDao(ITraineeDao obDao) {
		this.obDao = obDao;
	}






	@Override
	public Trainee addTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		
		return obDao.addTrainee(trainee);
		
	}



	@Override
	public Trainee getTraineeDetails(int id) {
		// TODO Auto-generated method stub
		return obDao.getTraineeDetails(id);
	}



	@Override
	public List<Trainee> getAllTraineeDetails() {
		// TODO Auto-generated method stub
		return obDao.getAllTraineeDetails();
	}



	@Override
	public Trainee deleteTrainee(int id) {
		// TODO Auto-generated method stub
		return obDao.deleteTrainee(id);
	}



	@Override
	public Trainee searchTrainee(int id) {
		// TODO Auto-generated method stub
		return obDao.searchTrainee(id);
	}



	@Override
	public Trainee updateTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		return obDao.updateTrainee(trainee);
	}




	
}
