package com.cg.traineeManagementSystem.service;

import java.util.List;

import com.cg.traineeManagementSystem.bean.Trainee;


public interface ITraineeService {

	public  Trainee addTrainee(Trainee trainee);
	public Trainee getTraineeDetails(int id);
	 public List<Trainee> getAllTraineeDetails();
	public Trainee deleteTrainee(int id);
	public Trainee searchTrainee(int id);
	public Trainee updateTrainee(Trainee trainee);
	
	
	
	

}
