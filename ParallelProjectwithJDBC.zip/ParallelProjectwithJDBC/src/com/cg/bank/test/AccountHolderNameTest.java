package com.cg.bank.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.cg.bank.service.AccountServiceImpl;
import com.cg.bank.service.IAccountService;

class AccountHolderNameTest {


		IAccountService service = new AccountServiceImpl();
		
		@Test
		public void test1() {
			//fail("Not yet implemented");
			String name = "piku";
			assertFalse(service.accHolderValidation(name));
		}
		
		@Test
		public void test2() {
			//fail("Not yet implemented");
			String name = "Piku";
			assertTrue(service.accHolderValidation(name));
		}
		
		
		
		public void test4() {
			//fail("Not yet implemented");
			String name = "@123";
			assertFalse(service.accHolderValidation(name));
		}
		
		@Test
		public void test5() {
			//fail("Not yet implemented");
			String name = "Abc";
			assertFalse(service.accHolderValidation(name));
		}
	
		
		@Test
		public void test7() {
			//fail("Not yet implemented");
			String name = null;
			assertFalse(service.accHolderValidation(name));
		}
	}
