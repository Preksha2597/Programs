package com.cg.bank.persistence;

public class QueryMapping {

	public static final String INSERT_QUERY="INSERT INTO accounts VALUES(accnumber.nextval, ?, ?, ?, ?, ?)";
	public static final String SEQ_CURR_VAL="SELECT accnumber.currval FROM dual";
	public static final String SELECT_BALENCE_QUERY="SELECT balance FROM accounts WHERE acnum=?";
	public static final String UPDATE_QUERY="UPDATE accounts SET balance=? WHERE acnum=?";
	public static final String INSERT_TRANSACTION="INSERT INTO transactions VALUES(?, ?, ?, ?, ?)";
	public static final String SELECT_TRANSACTION="SELECT * FROM transactions WHERE acnum=?";
}
