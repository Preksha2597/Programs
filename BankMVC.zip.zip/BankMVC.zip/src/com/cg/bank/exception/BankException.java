package com.cg.bank.exception;

public class BankException extends RuntimeException{
	public BankException(String msg) {
		super(msg); 	
	}
}
