package com.cg.bank.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

	@Entity
	@SequenceGenerator(name="AccNumSequence", initialValue=1, allocationSize=100001)
	@Table(name="Accounts")
	public class Account {

		@Id
		@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="AccNumSequence")
		private int accountnumber;
		
		@NotEmpty(message="Cannot Be Empty")
		@Pattern(regexp = "^[A-Z][\\p{L} ]+$", message = "Name Starts With Capital Letter")
		private String name;
		
		@NotEmpty(message="Cannot Be Empty")
		@Pattern(regexp = "^[6-9][0-9]{9}", message = "Enter A Valid Mobile Number")
		private String mobile;
		
		@NotEmpty(message="Cannot Be Empty")
		@Pattern(regexp = "^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$", message = "Enter A Valid E-Mail ID")
		private String email;
		
		private int pin;
		
		//@NotEmpty(message="Cannot Be Empty")
		//@Pattern(regexp = "^[0-9]*\\.?[0-9]*", message= "Balance Can Only Be Positive")
		private double balance;

		public int getAccountnumber() {
			return accountnumber;
		}

		public void setAccountnumber(int accountnumber) {
			this.accountnumber = accountnumber;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getMobile() {
			return mobile;
		}

		public void setMobile(String mobile) {
			this.mobile = mobile;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public double getBalance() {
			return balance;
		}

		public void setBalance(double balance) {
			this.balance = balance;
		}
		
		public int getPin() {
			return pin;
		}

		public void setPin(int pin) {
			this.pin = pin;
		}

		@Override
		public String toString() {
			return "Account-> Account Number: " + accountnumber + ", Name: " + name + ", Mobile: " + mobile + ", E-Mail: "
					+ email + ", Balance: " + balance + ", Pin: "+ pin + "\n";
		}
		
}
