package com.cg.bank.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.Transaction;
import com.cg.bank.dao.IBankDAO;
import com.cg.bank.exception.BankException;

@Service
@Transactional
public class BankServiceImpl implements IBankService{
	
	@Autowired
	private IBankDAO dao;
	
	@Override
	public void addAccount(Account account) throws BankException {
		dao.addAccount(account);
	}
	@Override
	public Account getAccountDetails(int accountnumber) throws BankException {
		return dao.getAccountDetails(accountnumber);
	}
	@Override
	public Transaction depositAmount(int accountnumber, double amount) throws BankException {
		return dao.depositAmount(accountnumber, amount);
	}
	@Override
	public Transaction withdrawAmount(int accountnumber, int pin, double amount) throws BankException {
		return dao.withdrawAmount(accountnumber, pin, amount);
	}
	@Override
	public void transferAmount(int accountnumber, int pin, int accountnumber2, double amount) throws BankException {
		dao.transferAmount(accountnumber, pin, accountnumber2, amount);
	}
	@Override
	public List<Transaction> showTransactions(int accountnumber, int pin) {
		return dao.showTransactions(accountnumber, pin);
	}

}
