package com.cg.bank.service;

import java.util.List;

import com.cg.bank.bean.Account;
import com.cg.bank.bean.Transaction;
import com.cg.bank.exception.BankException;

public interface IBankService {
	void addAccount(Account account) throws BankException;
	Account getAccountDetails(int accountnumber) throws BankException;
	Transaction depositAmount(int accountnumber, double amount) throws BankException;
	Transaction withdrawAmount(int accountnumber, int pin, double amount) throws BankException;
	void transferAmount(int accountnumber, int pin, int accountnumber2, double amount) throws BankException;
	List<Transaction> showTransactions(int accountnumber, int pin);
}
