package com.cg.bank.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bank.exception.BankException;

	@ControllerAdvice
	public class GlobalExceptionHandler {	
		@ExceptionHandler(value = {BankException.class})
	    protected ModelAndView handleConflict(Exception ex) {
			ModelAndView model = new ModelAndView("Error");
			model.addObject("msg", ex.getMessage());
			return model;
	    }
	}