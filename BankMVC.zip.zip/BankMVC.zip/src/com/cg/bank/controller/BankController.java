package com.cg.bank.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.bank.bean.Account;
import com.cg.bank.bean.Transaction;
import com.cg.bank.service.IBankService;

@Controller
public class BankController {
	@Autowired
	private IBankService service;

	public IBankService getService() {
		return service;
	}

	public void setService(IBankService service) {
		this.service = service;
	}

	@RequestMapping("/showHome")
	public String showHome() {
		return "Home";
	}

	@RequestMapping("/showAddNewAccountForm")
	public ModelAndView showAddAccount() {
		Account account = new Account();
		return new ModelAndView("AddAccountForm", "account", account);
	}

	@RequestMapping("/addAccount")
	public ModelAndView addTrainee(@ModelAttribute("account") @Valid Account account, BindingResult result) {
		ModelAndView mv = null;
		if (!result.hasErrors()) {
			service.addAccount(account);
			String success = "New Account Added Successfully:\n" + account + "";
			// return new ModelAndView("AddAccountForm","success",success);
			mv = new ModelAndView("AddAccountForm", "success", success);
		} else {
			List<FieldError> errors = result.getFieldErrors();
			List<String> errorMsgs = new ArrayList<String>();
			for (FieldError error : errors) {
				// System.out.println (error.getObjectName() + " - " +
				// error.getDefaultMessage());
				errorMsgs.add(error.getDefaultMessage());
			}
			mv = new ModelAndView("AddAccountForm", "account", account);
			mv.addObject("errors", errorMsgs);
		}
		return mv;
	}

	@RequestMapping("/showAccountDetailsForm")
	public String showIdpage() {
		return "ShowAccountDetailsForm";
	}

	@RequestMapping("/accountDetails")
	public ModelAndView getAccountDetails(@RequestParam("accountnumber") int accountnumber,
			@RequestParam("pin") int pin) {
		ModelAndView mv = new ModelAndView();
		if (service.getAccountDetails(accountnumber) == null) {
			String msg = "Failed! Trainee With ID " + accountnumber + " Not In Database";
			mv.setViewName("ShowAccountDetailsForm");
			mv.addObject("msg", msg);
		} else {
			if (service.getAccountDetails(accountnumber).getPin() == pin) {
				mv.setViewName("ShowAccountDetailsForm");
				mv.addObject("accountnumber", service.getAccountDetails(accountnumber));
			} else {
				String msg = "Failed! Incorrect PIN Entered For " + accountnumber + "";
				mv.setViewName("ShowAccountDetailsForm");
				mv.addObject("msg", msg);
			}
		}
		return mv;
	}

	@RequestMapping("/showDepositForm")
	public String showDepositForm() {
		return "ShowDepositForm";
	}

	@RequestMapping("/deposit")
	public ModelAndView deposit(@RequestParam("accountnumber") int accountnumber,
			@RequestParam("amount") double amount) {
		if (service.getAccountDetails(accountnumber) == null) {
			String msg = "Failed! Account With Account Number " + accountnumber + " Not In Database";
			return new ModelAndView("ShowDepositForm", "msg", msg);
		} else {
			service.depositAmount(accountnumber, amount);
			String success = "Amount " + amount + " Deposited To Account Number " + accountnumber;
			return new ModelAndView("ShowDepositForm", "success", success);
		}
	}

	@RequestMapping("/showWithdrawForm")
	public String showWithdrawForm() {
		return "ShowWithdrawForm";
	}

	@RequestMapping("/withdraw")
	public ModelAndView withdraw(@RequestParam("accountnumber") int accountnumber, @RequestParam("pin") int pin,
			@RequestParam("amount") double amount) {
		ModelAndView mv = new ModelAndView();
		if (service.getAccountDetails(accountnumber) == null) {
			String msg = "Failed! Account With Account Number " + accountnumber + " Not In Database";
			mv.setViewName("Error");
			mv.addObject("msg", msg);
			// return new ModelAndView("Error","msg",msg);
		} else {
			if (service.getAccountDetails(accountnumber).getPin() == pin) {
				service.withdrawAmount(accountnumber, pin, amount);
				String msg = "Amount " + amount + " Withdrawn From Account Number " + accountnumber;
				mv.setViewName("Success");
				mv.addObject("msg", msg);
				// return new ModelAndView("Success","msg",msg);
			} else {
				String msg = "Failed! Incorrect PIN Entered For " + accountnumber + "";
				mv.setViewName("Error");
				mv.addObject("msg", msg);
			}
		}
		return mv;
	}

	@RequestMapping("/showTransferForm")
	public String showTransferForm() {
		return "ShowTransferForm";
	}

	@RequestMapping("/transfer")
	public ModelAndView transfer(@RequestParam("accountnumber") int accountnumber, @RequestParam("pin") int pin,
			@RequestParam("accountnumber2") int accountnumber2, @RequestParam("amount") double amount) {
		ModelAndView mv = new ModelAndView();
		if (service.getAccountDetails(accountnumber) == null) {
			String msg = "Failed! Account With Account Number " + accountnumber + " Not In Database";
			mv.setViewName("Error");
			mv.addObject("msg", msg);
			// return new ModelAndView("Error","msg",msg);
		} else if (service.getAccountDetails(accountnumber2) == null) {
			String msg = "Failed! Account With Account Number " + accountnumber2 + " Not In Database";
			mv.setViewName("Error");
			mv.addObject("msg", msg);
		} else {
			if (service.getAccountDetails(accountnumber).getPin() == pin) {
				service.transferAmount(accountnumber, pin, accountnumber2, amount);
				String msg = "Amount " + amount + " Transfered From Account Number " + accountnumber
						+ " To Account Number " + accountnumber2;
				mv.setViewName("Success");
				mv.addObject("msg", msg);
				// return new ModelAndView("Success","msg",msg);
			} else {
				String msg = "Failed! Incorrect PIN Entered For " + accountnumber + "";
				mv.setViewName("Error");
				mv.addObject("msg", msg);
			}
		}
		return mv;
	}

	@RequestMapping("/showTransactionsForm")
	public String showTransactionsForm() {
		return "ShowTransactionsForm";
	}

	@RequestMapping("/showTransactions")
	public ModelAndView showTransactions(@RequestParam("accountnumber") int accountnumber,
			@RequestParam("pin") int pin) {
		ModelAndView mv = null; // new ModelAndView();
		if (service.getAccountDetails(accountnumber) == null) {
			String msg = "Failed! Trainee With ID " + accountnumber + " Not In Database";
			return new ModelAndView("Error", "msg", msg);
		} else {
			if (service.getAccountDetails(accountnumber).getPin() == pin) {
				List<Transaction> list = service.showTransactions(accountnumber, pin);
				mv = new ModelAndView("ShowTransactions", "list", list);
				mv.addObject("accountnumber", accountnumber);
			} else {
				String msg = "Failed! Incorrect PIN Entered For " + accountnumber + "";
				mv.setViewName("Error");
				mv.addObject("msg", msg);
			}
		}
		return mv;
	}
}
