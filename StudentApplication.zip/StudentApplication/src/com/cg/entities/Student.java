package com.cg.entities;

import java.io.Serializable;

import javax.annotation.Generated;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="students")
public class Student implements Serializable  {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	private int studentId;
	@NotEmpty(message="Please select a branch")
	private String branch;
	
	@NotEmpty(message="College cannot be empty")
	private String college;
	@NotEmpty(message="college location cannot be empty")
	private String location;
	@NotEmpty(message="preference1 cannot be empty")
	private String preference1;
	@NotEmpty(message="preference2 cannot be empty")
	private String preference2;
	@NotEmpty(message="preference3 cannot be empty")
	private String preference3;
	@NotEmpty(message="preference4 cannot be empty")
	private String preference4;
	
	@NotNull(message="hometown cannot be empty")
	@Min(value=1)
	@Max(value=4)
	private Integer homeTown;
	
	
	@NotNull(message="Optional subject  cannot be empty")
    @Min(value=0)
	private int optionalSubject;


	public int getStudentId() {
		return studentId;
	}


	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}


	public String getBranch() {
		return branch;
	}


	public void setBranch(String branch) {
		this.branch = branch;
	}


	public String getCollege() {
		return college;
	}


	public void setCollege(String college) {
		this.college = college;
	}


	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	public String getPreference1() {
		return preference1;
	}


	public void setPreference1(String preference1) {
		this.preference1 = preference1;
	}


	public String getPreference2() {
		return preference2;
	}


	public void setPreference2(String preference2) {
		this.preference2 = preference2;
	}


	public String getPreference3() {
		return preference3;
	}


	public void setPreference3(String preference3) {
		this.preference3 = preference3;
	}


	public String getPreference4() {
		return preference4;
	}


	public void setPreference4(String preference4) {
		this.preference4 = preference4;
	}


	public Integer getHomeTown() {
		return homeTown;
	}


	public void setHomeTown(Integer homeTown) {
		this.homeTown = homeTown;
	}


	public int getOptionalSubject() {
		return optionalSubject;
	}


	public void setOptionalSubject(int optionalSubject) {
		this.optionalSubject = optionalSubject;
	}


	

	
	
	
	
}
