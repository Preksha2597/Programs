package com.cg.service;

import com.cg.entities.Student;
import com.cg.exception.StudentException;

public interface IStudentService {

	public int addStudent(Student question)  throws StudentException ;
	
 
}
