package com.cg.exception;


public class StudentException extends RuntimeException {

	

	public StudentException(String msg) {
		super(msg);
        	
	}

	

}
