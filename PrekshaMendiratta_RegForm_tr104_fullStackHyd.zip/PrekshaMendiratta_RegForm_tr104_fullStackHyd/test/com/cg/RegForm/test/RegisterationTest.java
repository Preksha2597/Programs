package com.cg.RegForm.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"features"}, //which folder the feature file is stored in
		glue= {"com.cg.RegForm.stepDefinition"}, // the path of the step definition package for the feature file 
		tags= {"@RegistrationForm"}, //we specify which scenario we want cucumber to execute 
		plugin = { "pretty" } 

		)
public class RegisterationTest {

	//This is the TestRunner Class, which tests all the test cases given in the step definition file 
	
}
