package com.cg.RegForm.bean;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;


//this is the object repository class for web UI elements
public class RegisterationPageBean {
	@FindBy(how=How.NAME,name="userid") // for user id in html page 
	private WebElement userId ;

	@FindBy(how=How.NAME,name="passid") // for password in html page 
	private WebElement passid;

	@FindBy(how=How.NAME,name="username") //for Name in html page 
	private WebElement username;

	@FindBy(how=How.NAME,name="address") // for Address in html page 
	private WebElement address;

	@FindBy(how=How.NAME,name="country") // for Country in html page 
	private WebElement country;

	@FindBy(how=How.NAME,name="zip") // for Zip Code in html page 
	private WebElement zip;

	@FindBy(how=How.NAME,name="email") // for email in html page 
	private WebElement email;

	@FindBy(how=How.NAME,name="sex") // for Sex in html page 
	private List<WebElement> sex;

	@FindBy(how=How.NAME,name="languages") //for Languages in html page 
	private List<WebElement> languages;
	
	@FindBy(how=How.NAME,name="desc") // for description  in html page 
	private WebElement description;
	
	@FindBy(how=How.NAME,name="submit") // for the submit button in the Registration form.html 
	private WebElement submitButton;


	public String getUserId() {
		return userId.getAttribute("value");
	}

	public void setUserId(String  userId) {
		this.userId.clear();
		this.userId.sendKeys(userId);
	}

	public String getPassid() {
		return passid.getAttribute("value");
	}

	public void setPassid(String passid) {
		this.passid.clear();
		this.passid.sendKeys(passid);
	}

	public String getUsername() {
		return username.getAttribute("value");
	}

	public void setUsername(String username) {
		this.username.clear();
		this.username.sendKeys(username);
	}
	public String getAddress() {
		return address.getAttribute("value");
	}
	public void setAddress(String address) {
		this.address.clear();
		this.address.sendKeys(address);
	}



	public String getCountry() {
		return new Select(this.country).getFirstSelectedOption().getText();
	}

	public void setCountry(String country) {
		Select select=new Select(this.country);
		select.selectByVisibleText(country);
	}

	public String getZip() {
		return zip.getAttribute("zip");
	}

	public void setZip(String zip) {
		this.zip.clear();
		this.zip.sendKeys(zip);
	}

	public String getEmail() {
		return email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.clear();
		this.email.sendKeys(email);;
	}

	public String  getSex() {
		for (WebElement webElement : sex) 
			if(webElement.isSelected())
				return webElement.getAttribute("value");
		return null;
	}

	public void setSex(String gender) {
		if(gender.equals("female"))
			this.sex.get(0).click();
		else 
			this.sex.get(1).click();
	}

	public String[]  getLanguage() {
		return null;
	}

	public void setLanguage(String [] languages) {
		for (String language : languages) {
			if(language.equals("english"))
				this.languages.get(0).click();
			else if(language.equals("nonenglish"))
				this.languages.get(1).click();
		}

	}

	
	public String getDescription() {
		return description.getAttribute("value");
	}

	public void setDescription(String description) {
		this.description.clear();
		this.description.sendKeys(description);
	}

	public void clickSubmit() { //method for clicking the submit button
		submitButton.submit();
	}
}
