package com.cg.RegForm.stepDefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.RegForm.bean.RegisterationPageBean;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
//this is the step definition class 
public class RegisterationStepDefinition {
// the driver instance
	private WebDriver driver;
//the pagebean class object 
	private RegisterationPageBean pageBean;

	@Before //the test case which will open the browser by the path of the chromedriver.exe given in the setPropertyMethod
	public void setUpBrowser() {
		System.setProperty("webdriver.chrome.driver",
				"MyDriver\\\\chromedriver.exe" );
		driver=new ChromeDriver();	
	}

	@Given("^User is on JobsWorld Page and accessing RegisterForm on the Browser$")
	public void user_is_on_JobsWorld_Page_and_accessing_RegisterForm_on_the_Browser() throws Throwable {
		driver.get("D:\\Users\\PMENDIRA\\Desktop\\bdd mpt\\WebPages\\RegistrationForm.html");
		pageBean = PageFactory.initElements(driver, RegisterationPageBean.class); //object Repository class
		driver.manage().window().maximize();
		
	}
	@Given("^'Welcome to JobsWorld' is the title of the page$")
	public void welcome_to_JobsWorld_is_the_title() throws Throwable {
	   // throw new PendingException();
		String actualTitle=driver.getTitle();
		//the title in The registration page.html is blank
		String expectedTitle ="";
		Assert.assertEquals(expectedTitle, actualTitle);
		System.out.println("Title Matched and the title of Page is Welcome to JobsWorld");
	}


	@When("^User is submiting data with invalid entry of 'User Id'$")
	public void user_is_submiting_data_with_invalid_entry_of_User_Id() throws Throwable {
		pageBean.clickSubmit();
	}

	@Then("^alert box should display the message 'User Id should not be empty / length be between (\\d+) to (\\d+)'$")
	public void alert_box_should_display_the_message_User_Id_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {
		Thread.sleep(2000); // for giving a waiting time 
		String expectedAlertMessage ="User Id should not be empty / length be between 5 to 12";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@When("^User is submiting data with invalid entry of 'Password'$")
	public void user_is_submiting_data_with_invalid_entry_of_Password() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setUserId("Preksha2597");
		pageBean.clickSubmit();
	}

	@Then("^alert box should display the message 'Password should not be empty / length be between (\\d+) to (\\d+)'$")
	public void alert_box_should_display_the_message_Password_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {
		Thread.sleep(2000); // for giving a waiting time 
		String expectedAlertMessage ="Password should not be empty / length be between 7 to 12";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@When("^User is submiting data with invalid entry of 'Name'$")
	public void user_is_submiting_data_with_invalid_entry_of_Name() throws Throwable {
	    driver.switchTo().alert().dismiss();
		pageBean.setPassid("prekshapiku");
		pageBean.clickSubmit();
	}

	@Then("^alert box should display the message 'Name should not be empty and must have alphabet characters only'$")
	public void alert_box_should_display_the_message_Name_should_not_be_empty_and_must_have_alphabet_characters_only() throws Throwable {
		Thread.sleep(2000);
		String expectedAlertMessage ="Name should not be empty and must have alphabet characters only";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@When("^User is submiting data with invalid entry of 'address'$")
	public void user_is_submiting_data_with_invalid_entry_of_address() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setUsername("PrekshaMendiratta");
		pageBean.setAddress("Indira62@@$");
		pageBean.clickSubmit();
	}

	@Then("^alert box should display the message 'User address must have alphanumeric characters only'$")
	public void alert_box_should_display_the_message_User_address_must_have_alphanumeric_characters_only() throws Throwable {
		Thread.sleep(2000); // for giving a waiting time 
		String expectedAlertMessage ="User address must have alphanumeric characters only";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@When("^User is submiting data without selecting valid entry of 'country'$")
	public void user_is_submiting_data_without_selecting_valid_entry_of_country() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setAddress("HydTelecom62");
		pageBean.setCountry("(Please select a country)");
		pageBean.clickSubmit();
	}

	@Then("^alert box should display the message 'Select your country from the list'$")
	public void alert_box_should_display_the_message_Select_your_country_from_the_list() throws Throwable {
		Thread.sleep(2000); // for giving a waiting time 
		String expectedAlertMessage="Select your country from the list";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@When("^User is submiting data with invalid entry of 'zipCode'$")
	public void user_is_submiting_data_with_invalid_entry_of_zipCode() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setCountry("India");
		pageBean.clickSubmit();
	}

	@Then("^alert box should display the message 'ZIP code must have numeric characters only'$")
	public void alert_box_should_display_the_message_ZIP_code_must_have_numeric_characters_only() throws Throwable {
		Thread.sleep(2000); // for giving a waiting time 
		String expectedAlertMessage="ZIP code must have numeric characters only";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@When("^User is submiting data with invalid entry of 'email'$")
	public void user_is_submiting_data_with_invalid_entry_of_email() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setZip("303007");
		pageBean.setEmail("preksham%gmail.com");
		pageBean.clickSubmit();
	}

	@Then("^alert box should display the message 'You have entered an invalid email address!'$")
	public void alert_box_should_display_the_message_You_have_entered_an_invalid_email_address() throws Throwable {
		Thread.sleep(2000);
		String expectedAlertMessage="You have entered an invalid email address!";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@When("^User is submiting data with invalid entry of 'sex'$")
	public void user_is_submiting_data_with_invalid_entry_of_sex() throws Throwable {
		driver.switchTo().alert().dismiss();
		pageBean.setEmail("preksham@gmail.com");
		pageBean.clickSubmit();
	}

	@Then("^alert box should display the message 'Please Select gender'$")
	public void alert_box_should_display_the_message_Please_Select_gender() throws Throwable {
		Thread.sleep(2000); // for giving a waiting time 
		String expectedAlertMessage="Please Select gender";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@When("^User is submitting data with entring valid set of information$")//when giving the corrct data
	public void user_is_submitting_data_with_entring_valid_set_of_information() throws Throwable {
		pageBean.setUserId("Preksha2597");
		pageBean.setPassid("prekshapiku");
		pageBean.setUsername("PrekshaMendiratta");
		pageBean.setAddress("HydTelecom62");
		pageBean.setCountry("India");
		pageBean.setZip("303007");
		pageBean.setEmail("preksham@gmail.com");
		pageBean.setSex("Female");
		pageBean.setDescription("Kindly get me notified on my successful registeration. please feel free to drop a mail regarding any queries ");
		Thread.sleep(2000); // for giving a waiting time 
		pageBean.clickSubmit();
	}

	@Then("^'Your Registration with JobsWorld\\.com has successfully done plz check your registred email addres to activate your profile'$")
	public void your_Registration_with_JobsWorld_com_has_successfully_done_plz_check_your_registred_email_addres_to_activate_your_profile() throws Throwable {
		Thread.sleep(2000); // for giving a waiting time 
		String expectedAlertMessage="Your Registration with JobsWorld.com has successfully done plz check your registred email addres to activate your profile";
		String actualAlertMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedAlertMessage, actualAlertMessage);
	}

	@After
	public void closeBrowser() {
		driver.switchTo().alert().dismiss();
		driver.close();
	}
}
